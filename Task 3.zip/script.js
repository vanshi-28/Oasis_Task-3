function convertTemp() {
    var inputDegree = document.getElementById("degrees").value;
    var type = document.getElementById("type").value;
    var result;
    var resultStr;

    if (isNaN(inputDegree)) {
        alert("Please enter valid number as input!")
        return;
    }
    
    if (type === "Fahrenheit") {
    result = (parseFloat(inputDegree) - 32) * (5 / 9);
    resultStr = result + " °C";
    }

    else if (type === "Celcius") {
    result = ((9 / 5) * parseFloat(inputDegree)) + 32;
    resultStr = result + " °F";
    }

    document.getElementById("result").innerHTML = resultStr;
}